""" A simple execution time logger implemented as a python decorator. Available under the terms of the MIT license."""

__version__ = "0.1"

from .log_decorator import timed, add_handler