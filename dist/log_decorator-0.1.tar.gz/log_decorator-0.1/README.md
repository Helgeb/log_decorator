# log_decorator

Python logging decorator

Based on a gist from https://gist.github.com/bradmontgomery
